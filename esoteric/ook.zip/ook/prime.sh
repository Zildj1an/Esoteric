echo ... Compiling Brainf*ck to Ook# converter
./ook.exe -ook bf2ook.exe bf2ook.ook

echo Converting prime.b to prime.ook
./bf2ook.exe < prime.b > prime.ook

echo Compiling prime.ook
./ook.exe prime.ook

echo start prime.exe
./prime.exe