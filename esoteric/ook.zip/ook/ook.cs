//
// ook.cs: The Ook# compiler v1.0
//
// Author:
//   Lawrence Pit (lawrence@bluesorcerer.net)
//

using System;
using System.IO;
using System.Reflection.Emit;
using System.Text;
using System.Text.RegularExpressions;

namespace BlueSorcerer
{
	public class OokGenerator : Brainf_ckGenerator
	{
		protected override void Usage ()
		{
			Console.WriteLine (
				"Usage: ook [options] source-file\n" +
				"Options:\n" +
				"  -ook!         Display this information\n" + 
				"  -ook?         Generate debugging information\n" + 
				"  -ook <file>   Specifies output file\n\n" +
				"For more information on Ook#, please see:\n" +
				"   http://bluesorcerer.net\n");
		}
		
		protected override void Logo ()
		{
			Console.WriteLine (
				"BlueSorcerer (R) Ook# .NET Compiler version 1.0\n" +
				"Copybananas (C) BlueSorcerer 2002. All trees reserved.\n"); 
		}
		
		new public static void Main (string[] args)
		{	
			OokGenerator ook = new OokGenerator ();
			ook.prefixErr = "Oooook!   (English translation: ";
			ook.postfixErr = ")";
			ook.openingToken = "Ook! Ook?";
			ook.closingToken = "Ook? Ook!";
			if (!ook.Parse (args))
				return;
			try {				
				OokStream ookStream = new OokStream (ook.Path);
				AssemblyBuilder assembly = ook.Compile (ookStream);
				ookStream.Close ();			
				ook.Save (assembly);
			} catch (FileNotFoundException) {
				Console.WriteLine (ook.prefixErr + "File " + ook.Path + " not found!" + ook.postfixErr);
			}
		}
	}
	
	internal class OokStream : FileStream
	{	
		private string source;
		private int index = 0;
		private int len = 0;
		
		public String OokMatch (Match match)
		{
			string str1 = match.Groups [1].Captures [0].Value;
			string str2 = match.Groups [2].Captures [0].Value;
			
			if (str1 == ".") {
				if (str2 == "?")
					return ">";
				else if (str2 == ".")
					return "+";
				else if (str2 == "!")
					return ",";
			} else if (str1 == "?") {
				if (str2 == ".")
					return "<";
				else if (str2 == "!") 
					return "]";
			} else if (str1 == "!") {
				if (str2 == "!")
					return "-";
				else if (str2 == ".")
					return ".";
				else if (str2 == "?")
					return "[";
			}
			return "";
		}
		
		public OokStream (string path) 
			: base (path, FileMode.Open, FileAccess.Read, FileShare.Read)
		{
			StringBuilder b = new StringBuilder ((int) base.Length);
			int c = 0;
			while ((c = base.ReadByte ()) != -1)
				b.Append ((char) c);
			source = b.ToString ();
			source = Regex.Replace (source, @"[+-,\[\]<>]", "");
			Regex r = new Regex (@"Ook([?!\.])\s+Ook([?!\.])");
			source = r.Replace (source, new MatchEvaluator (this.OokMatch));
			source = source.Replace (" ", "");
			source = source.Replace ("\r", "");
			source = source.Replace ("\n", "");
			len = source.Length;
		}
		
		public override int ReadByte ()
		{
			return index == len ? -1 : source [index++];	
		}
	}
}
