./ook -ook hello.exe hello.ook
./hello